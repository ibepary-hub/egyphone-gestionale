Unicode true
!ifndef PAYLOAD_DIR
!define PAYLOAD_DIR "installer-payload"
!endif
!include "MUI2.nsh"
!include "x64.nsh"
!define APPNAME "EgyPhone Desktop"
!define VERSION "1.6.0"
Name "${APPNAME} ${VERSION}"
OutFile "dist/EgyPhone-Desktop-Setup-1.6.0.exe"
InstallDir "$LOCALAPPDATA\Programs\EgyPhone Desktop"
InstallDirRegKey HKCU "Software\EgyPhone Desktop" "InstallDir"
RequestExecutionLevel user
SetCompressor /SOLID zlib

BrandingText "EGYPHONE · Il tuo laboratorio, online e offline"
VIProductVersion "1.6.0.0"
VIAddVersionKey /LANG=1040 "ProductName" "EgyPhone Desktop"
VIAddVersionKey /LANG=1040 "FileDescription" "Installazione EgyPhone Desktop"
VIAddVersionKey /LANG=1040 "FileVersion" "1.6.0"
VIAddVersionKey /LANG=1040 "LegalCopyright" "EgyPhone 2026"
!define MUI_ICON "assets/icon.ico"
!define MUI_UNICON "assets/icon.ico"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Benvenuto in EgyPhone Desktop"
!define MUI_WELCOMEPAGE_TEXT "Accettazioni, rubrica clienti e riparazioni in una vera applicazione Windows.$\r$\n$\r$\nFunziona online e offline. Il primo accesso al tuo account richiede Internet.$\r$\n$\r$\nLa disinstallazione conserva i dati locali e le modifiche non ancora sincronizzate."
!define MUI_FINISHPAGE_RUN "$INSTDIR\EgyPhone Desktop.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Apri EgyPhone Desktop"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Italian"
Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_ICONSTOP "Questa versione richiede Windows 10 o 11 a 64 bit."
    Abort
  ${EndIf}
  FindWindow $0 "" "EgyPhone Desktop"
  ${If} $0 != 0
    MessageBox MB_ICONINFORMATION "Chiudi EgyPhone Desktop prima di installare o aggiornare. I dati restano salvati sul PC."
    Abort
  ${EndIf}
FunctionEnd
Section "EgyPhone Desktop" SEC_APP
  SetShellVarContext current
  SetOutPath "$INSTDIR"
  File /r "${PAYLOAD_DIR}\*"
  WriteUninstaller "$INSTDIR\Disinstalla EgyPhone.exe"
  WriteRegStr HKCU "Software\EgyPhone Desktop" "InstallDir" "$INSTDIR"
  CreateDirectory "$SMPROGRAMS\EgyPhone Desktop"
  CreateShortcut "$SMPROGRAMS\EgyPhone Desktop\EgyPhone Desktop.lnk" "$INSTDIR\EgyPhone Desktop.exe" "" "$INSTDIR\resources\app.ico"
  CreateShortcut "$DESKTOP\EgyPhone Desktop.lnk" "$INSTDIR\EgyPhone Desktop.exe" "" "$INSTDIR\resources\app.ico"
  CreateShortcut "$SMPROGRAMS\EgyPhone Desktop\Disinstalla.lnk" "$INSTDIR\Disinstalla EgyPhone.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EgyPhoneDesktop" "DisplayName" "EgyPhone Desktop"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EgyPhoneDesktop" "DisplayVersion" "1.6.0"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EgyPhoneDesktop" "Publisher" "EgyPhone"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EgyPhoneDesktop" "UninstallString" '"$INSTDIR\Disinstalla EgyPhone.exe"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EgyPhoneDesktop" "DisplayIcon" "$INSTDIR\resources\app.ico"
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EgyPhoneDesktop" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EgyPhoneDesktop" "NoRepair" 1
SectionEnd
Function un.onInit
  FindWindow $0 "" "EgyPhone Desktop"
  ${If} $0 != 0
    MessageBox MB_ICONINFORMATION "Chiudi prima EgyPhone Desktop."
    Abort
  ${EndIf}
FunctionEnd
Section "Uninstall"
  SetShellVarContext current
  !include "uninstall-files.nsh"
  Delete "$INSTDIR\Disinstalla EgyPhone.exe"
  RMDir "$INSTDIR"
  Delete "$DESKTOP\EgyPhone Desktop.lnk"
  Delete "$SMPROGRAMS\EgyPhone Desktop\EgyPhone Desktop.lnk"
  Delete "$SMPROGRAMS\EgyPhone Desktop\Disinstalla.lnk"
  RMDir "$SMPROGRAMS\EgyPhone Desktop"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\EgyPhoneDesktop"
  DeleteRegKey HKCU "Software\EgyPhone Desktop"
SectionEnd
