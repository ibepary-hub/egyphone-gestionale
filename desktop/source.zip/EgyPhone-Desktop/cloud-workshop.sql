-- Additive EgyPhone-only storage. No existing tables or rows are changed.
create table public.egyphone_desktop_workshop (
 id bigint primary key check (id = 1),
 workspace_owner_id uuid not null check (workspace_owner_id = '7834b431-968b-467a-be04-96efe3aaf132'::uuid),
 created_by uuid not null references auth.users(id),
 data jsonb not null check (jsonb_typeof(data) = 'object'),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default clock_timestamp()
);
alter table public.egyphone_desktop_workshop enable row level security;
revoke all on public.egyphone_desktop_workshop from anon, authenticated;
grant select, insert, update on public.egyphone_desktop_workshop to authenticated;
create policy egyphone_workshop_read on public.egyphone_desktop_workshop for select to authenticated using (
 workspace_owner_id = '7834b431-968b-467a-be04-96efe3aaf132'::uuid and exists (
 select 1 from public.beparytech_profiles p where p.user_id=(select auth.uid()) and p.active and p.role='admin' and p.workspace_owner_id=egyphone_desktop_workshop.workspace_owner_id)
 and (select private.bt_license_active())
);
create policy egyphone_workshop_create on public.egyphone_desktop_workshop for insert to authenticated with check (
 created_by=(select auth.uid()) and workspace_owner_id='7834b431-968b-467a-be04-96efe3aaf132'::uuid and exists (
 select 1 from public.beparytech_profiles p where p.user_id=(select auth.uid()) and p.active and p.role='admin' and p.workspace_owner_id=egyphone_desktop_workshop.workspace_owner_id)
 and (select private.bt_license_active())
);
create policy egyphone_workshop_update on public.egyphone_desktop_workshop for update to authenticated using (
 workspace_owner_id='7834b431-968b-467a-be04-96efe3aaf132'::uuid and exists (
 select 1 from public.beparytech_profiles p where p.user_id=(select auth.uid()) and p.active and p.role='admin' and p.workspace_owner_id=egyphone_desktop_workshop.workspace_owner_id)
 and (select private.bt_license_active())
) with check (
 workspace_owner_id='7834b431-968b-467a-be04-96efe3aaf132'::uuid and exists (
 select 1 from public.beparytech_profiles p where p.user_id=(select auth.uid()) and p.active and p.role='admin' and p.workspace_owner_id=egyphone_desktop_workshop.workspace_owner_id)
 and (select private.bt_license_active())
);
create function public.egyphone_workshop_revision() returns trigger language plpgsql security invoker set search_path='' as $$begin new.updated_at=clock_timestamp();return new;end$$;
revoke all on function public.egyphone_workshop_revision() from public,anon,authenticated;
create trigger egyphone_workshop_revision before update on public.egyphone_desktop_workshop for each row execute function public.egyphone_workshop_revision();
