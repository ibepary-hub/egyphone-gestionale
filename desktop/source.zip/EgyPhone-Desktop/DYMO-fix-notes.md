# Correzione ImageObject DYMO 1.5.1

Fonte: pacchetto ufficiale DYMO.Connect.SDK 1.4.3.37, https://www.nuget.org/packages/DYMO.Connect.SDK/1.4.3.37
Componente: Build/DYMOLib/DYMO.LabelAPI.dll
SHA256: c6bfd8f38df6feed18fbc94f0ccf07c5c24a456e5263dc0041a098af8be0c569

Analisi dei metodi nativi (non una prova contro il servizio Windows):
- BaseLabelObject.Serialize: scrive proprietà, poi ObjectLayout.
- BaseLabelObject.WriteProperties: Name, Brushes, Rotation, OutlineThickness, IsOutlined, BorderStyle, Margin.
- ImageObject.WriteProperties: base, Data, ScaleMode, HorizontalAlignment, VerticalAlignment.
- ImageObject.ReadProperties legge i valori nello stesso ordine, con ReadElementContentAsString e conversione del secondo in EScaleMode.
- EScaleMode ammette None, Fill, Uniform; Middle non è valido.

Prima: Data veniva scritto dopo gli allineamenti. Dopo: Data, ScaleMode, HorizontalAlignment, VerticalAlignment, ObjectLayout. Il test controlla il contratto del lettore nativo oltre al riconoscimento del framework JavaScript.
