'use strict';
const crypto=require('node:crypto');
const {gross,cents,WORKSPACE}=require('./core');
const uid=prefix=>prefix+'-'+new Date().getFullYear()+'-'+crypto.randomUUID().slice(0,8).toUpperCase();
const clean=(x,n=240)=>String(x??'').trim().slice(0,n);
const money=x=>{const v=cents(x);if(!Number.isSafeInteger(v)||v<0)throw Error('Importo non valido.');return v/100;};
const METHODS=['Contanti','Carta / POS','Bonifico','Misto','Nessun incasso'];
function initial(){return{items:[],pieces:[],receipts:[],requests:[],documents:[],movements:[],catalog:{Apple:['iPhone 7','iPhone 7 Plus','iPhone 8','iPhone 8 Plus','iPhone X','iPhone XR','iPhone XS','iPhone XS Max','iPhone 11','iPhone 11 Pro','iPhone 11 Pro Max','iPhone 12 mini','iPhone 12','iPhone 12 Pro','iPhone 12 Pro Max','iPhone 13 mini','iPhone 13','iPhone 13 Pro','iPhone 13 Pro Max','iPhone 14','iPhone 14 Plus','iPhone 14 Pro','iPhone 14 Pro Max','iPhone 15','iPhone 15 Plus','iPhone 15 Pro','iPhone 15 Pro Max','iPhone 16','iPhone 16 Plus','iPhone 16 Pro','iPhone 16 Pro Max','iPhone 16e','iPhone 17','iPhone 17 Pro','iPhone 17 Pro Max','iPhone Air','iPhone 17e','iPhone SE (1ª gen.)','iPhone SE (2ª gen.)','iPhone SE (3ª gen.)'],Samsung:['Galaxy S23','Galaxy S24','Galaxy A54','Galaxy A55'],Xiaomi:['Redmi Note 12','Redmi Note 13','Xiaomi 14'],Console:['PlayStation 5','PlayStation 4','Nintendo Switch','Xbox Series X']}};}
function data(state){return state.workshop?.[1]?.data||initial();}
function run(engine,command,p={}){
 const before=JSON.parse(JSON.stringify(engine.state)),persist=engine.persist;engine.persist=()=>{};
 try{const d=JSON.parse(JSON.stringify(data(engine.state))),now=new Date().toISOString();let result;
 const repair=()=>{const r=engine.state.repairs[Number(p.repairId)];if(!r)throw Error('Riparazione non trovata.');return r;};
 const item=()=>{const i=d.items.find(i=>i.id===p.itemId);if(!i)throw Error('Ricambio non trovato.');return i;};
 const audit=(type,detail)=>d.movements.unshift({id:uid('MOV'),at:now,type,...detail});
 if(command==='item'){
  const name=clean(p.name,1000),brand=clean(p.brand),model=clean(p.model,1000);if(!name||!brand||!model)throw Error('Inserisci marca, modello e ricambio.');
  const old=p.itemId?item():null;const epolId=clean(p.epolId,20);if(epolId&&!/^\d+$/.test(epolId))throw Error('L’ID E-POL deve contenere soltanto cifre.');
  if(epolId&&d.items.some(x=>x.epolId===epolId&&x.id!==old?.id))throw Error('ID E-POL già presente: usa la scheda esistente.');
  const minimum=Number(p.minimum||0);if(!Number.isInteger(minimum)||minimum<0)throw Error('Scorta minima non valida.');
  const row={...old,id:old?.id||uid('ART'),name,brand,model,quality:clean(p.quality),location:clean(p.location),epolId,supplier:clean(p.supplier),supplierCode:p.supplierCode===undefined?(old?.supplierCode||''):clean(p.supplierCode),sale:p.sale===''||p.sale===null?null:money(p.sale),minimum,reference:false};
  if(old)Object.assign(old,row);else d.items.push(row);if(!d.catalog[brand])d.catalog[brand]=[];if(!d.catalog[brand].includes(model))d.catalog[brand].push(model);audit('Articolo salvato',{itemId:row.id});result=row;
 }else if(command==='receive'){
  const i=item(),quantity=Number(p.quantity),cost=money(p.cost),supplier=clean(p.supplier),document=clean(p.document);if(!Number.isInteger(quantity)||quantity<1||quantity>500)throw Error('Quantità da 1 a 500 pezzi.');if(!supplier||!document)throw Error('Inserisci fornitore e documento di acquisto.');
  const request=p.requestId?d.requests.find(x=>x.id===p.requestId&&x.itemId===i.id&&!['received','cancelled'].includes(x.status)):null;if(p.requestId&&!request)throw Error('Richiesta già ricevuta o non valida.');
  const receipt={id:uid('EM'),at:now,itemId:i.id,quantity,cost,supplier,supplierCode:clean(p.supplierCode),document};d.receipts.unshift(receipt);
  const pieces=Array.from({length:quantity},(_,index)=>({id:uid('RC'),itemId:i.id,receiptId:receipt.id,supplier,supplierCode:receipt.supplierCode,cost,epolId:i.epolId,status:request&&index===0?'reserved':'available',repairId:request&&index===0?request.repairId:null}));d.pieces.push(...pieces);if(request){request.status='received';request.pieceId=pieces[0].id;}audit('Entrata merci',{receiptId:receipt.id,itemId:i.id,quantity});result=receipt;
 }else if(command==='associate'){
  const r=repair(),i=item();if(r.repair_status==='Consegnato')throw Error('La pratica è già ritirata.');const piece=d.pieces.find(x=>x.itemId===i.id&&x.status==='available');
  if(piece){piece.status='reserved';piece.repairId=r.id;audit('Riserva ricambio',{pieceId:piece.id,repairId:r.id});result=piece;}
  else{const existing=d.requests.find(x=>x.itemId===i.id&&x.repairId===r.id&&!['received','cancelled'].includes(x.status));if(existing)throw Error('Il ricambio è già nell’elenco Da ordinare.');const request={id:uid('ORD'),itemId:i.id,repairId:r.id,status:'needed',at:now};d.requests.push(request);engine.save('repairs',{...r,total:gross(r),mode:'quick',repair_status:'Attesa ricambio'});audit('Richiesta ricambio',{requestId:request.id,repairId:r.id});result=request;}
 }else if(command==='consume'||command==='release'){
  const piece=d.pieces.find(x=>x.id===p.pieceId&&x.status==='reserved');if(!piece)throw Error('Pezzo non riservato.');if(command==='consume'){piece.status='used';piece.usedAt=now;}else{piece.status='available';piece.repairId=null;}audit(command==='consume'?'Scarico utilizzo':'Rilascio riserva',{pieceId:piece.id,repairId:piece.repairId});result=piece;
 }else if(command==='ordered'){
  const request=d.requests.find(x=>x.id===p.requestId&&x.status==='needed');if(!request)throw Error('Richiesta non disponibile.');request.status='ordered';request.supplier=clean(p.supplier);audit('Segnato ordinato',{requestId:request.id});result=request;
 }else if(command==='link'){
  const piece=d.pieces.find(x=>x.id===p.pieceId),epolId=clean(p.epolId,20);if(!piece||!/^\d+$/.test(epolId)||p.compatible!==true)throw Error('Verifica compatibilità e ID E-POL.');piece.epolId=epolId;audit('Riferimento E-POL associato',{pieceId:piece.id,epolId,supplier:piece.supplier});result=piece;
 }else if(command==='costReview'){
  const r=repair();if(p.confirm!==true)throw Error('Conferma che non sono stati utilizzati ricambi.');if(d.pieces.some(x=>x.repairId===r.id&&['reserved','used'].includes(x.status)))throw Error('Sono presenti ricambi riservati o utilizzati.');d.costReviewed??={};d.costReviewed[r.id]=true;audit('Conferma costo ricambi zero',{repairId:r.id});result=true;
 }else if(command==='model'){
  const brand=clean(p.brand,60),model=clean(p.model,120);if(!brand||!model)throw Error('Inserisci marca e modello.');if(!d.catalog[brand])d.catalog[brand]=[];if(d.catalog[brand].some(x=>x.toLowerCase()===model.toLowerCase()))throw Error('Modello già presente.');d.catalog[brand].push(model);result={brand,model};
 }else if(command==='courtesy'||command==='pickup'){
  const r=repair(),existing=d.documents.find(x=>x.repairId===r.id&&x.kind===command);if(existing){engine.persist=persist;return existing;}
  if(command==='pickup'&&r.repair_status==='Consegnato')throw Error('Pratica già consegnata: completa i documenti esistenti, senza registrare un nuovo incasso.');
  if(command==='pickup'&&d.requests.some(x=>x.repairId===r.id&&!['received','cancelled'].includes(x.status)))throw Error('Ci sono ricambi ancora da ricevere.');
  const deposit=money(r.deposit_amount),total=money(gross(r)),balance=Math.max(0,Math.round((total-deposit)*100)/100);
  const method=clean(p.method,40),depositMethod=clean(p.depositMethod,40);if(!METHODS.includes(depositMethod)||deposit>0&&depositMethod==='Nessun incasso')throw Error('Indica il metodo dell’acconto già registrato.');
  if(command==='pickup'&&(p.confirm!==true||!METHODS.includes(method)||balance>0&&method==='Nessun incasso'))throw Error('Conferma consegna e metodo del saldo.');
  const first=d.documents.find(x=>x.repairId===r.id&&x.kind==='courtesy');if(first&&(first.total!==total||first.deposit!==deposit))throw Error('Importi diversi dallo scontrino di acconto: rettifica la pratica prima di chiudere.');
  if(command==='pickup'&&d.pieces.some(x=>x.repairId===r.id&&x.status==='reserved'))throw Error('Conferma prima l’utilizzo o libera i ricambi riservati.');
  const doc={id:uid('SC'),kind:command,at:now,repairId:r.id,practice:r.practice_code,client:r.client_name,device:r.device,work:r.repair_type,total,deposit,depositMethod:first?.depositMethod||depositMethod,paidNow:command==='pickup'?balance:deposit,method:command==='pickup'?method:depositMethod,due:command==='pickup'?0:balance,collector:command==='pickup'?clean(p.collector)||r.client_name:null};d.documents.push(doc);
  if(command==='pickup')engine.save('repairs',{...r,total,mode:'quick',repair_status:'Consegnato'});audit(command==='pickup'?'Ritiro e saldo':'Documento acconto',{documentId:doc.id,repairId:r.id,paidNow:doc.paidNow});result=doc;
 }else throw Error('Operazione non riconosciuta.');
 engine.save('workshop',{id:1,data:d});engine.persist=persist;persist(engine.state);return result;
 }catch(e){engine.state=before;engine.persist=persist;throw e;}
}
module.exports={initial,data,run,METHODS,uid};
