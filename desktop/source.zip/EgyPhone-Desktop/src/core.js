'use strict';
const crypto = require('node:crypto');
const WORKSPACE = '7834b431-968b-467a-be04-96efe3aaf132';
const TABLES = { repairs: 'beparytech_admin_repairs', clients: 'beparytech_clients', workshop:'egyphone_desktop_workshop' };
const STATUSES = ['Da completare','Da diagnosticare','Da riparare','In lavorazione','Attesa ricambio','Attesa cliente','Riparato','Pronto','Consegnato'];
const TERMS = 'La data di riconsegna è indicativa. Il cliente è invitato ad effettuare un backup dei dati: salvo specifico servizio concordato, il laboratorio non garantisce conservazione, recupero o integrità dei dati. Durante la lavorazione possono emergere guasti o fragilità preesistenti non rilevabili alla consegna. Eventuali danni direttamente causati da una lavorazione non corretta restano a carico del laboratorio secondo la normativa applicabile. I dati personali sono trattati per la gestione della pratica, della riparazione, delle comunicazioni e degli obblighi amministrativi connessi.';
const clone = x => JSON.parse(JSON.stringify(x));
const cents = v => Math.round(Number(String(v ?? 0).replace(',','.')) * 100);
const money = c => c / 100;
// quote_amount keeps the exact customer-facing gross price; the legacy cloud
// net-price column has two decimals and can derive a +/- 1 cent gross difference.
const gross = r => r.quote_amount != null ? Number(r.quote_amount) : r.total_inc_vat != null ? Number(r.total_inc_vat) : Math.round(Number(r.price_ex_vat || 0) * (1 + Number(r.vat_rate ?? 22)/100)*100)/100;
function text(v, max=1000) { return String(v ?? '').trim().slice(0,max); }
function newId() { return 100000000000000 + crypto.randomBytes(6).readUIntBE(0,6); }
function emptyState() { return {version:1,identity:null,auth:{},repairs:{},clients:{},workshop:{},queue:[],photoCache:{},settings:{printer:''},lastSync:null}; }
function normalizeRepair(input, existing, identity) {
  const now = new Date().toISOString(), date = text(input.repaired_at,10) || now.slice(0,10);
  const client = text(input.client_name,120), device=text(input.device,160), work=text(input.repair_type,240);
  if (!client || !device || !work) throw Error('Inserisci cliente, dispositivo e intervento.');
  const totalCents = cents(input.total), depositCents = cents(input.deposit_amount), vat=Number(input.vat_rate ?? 22);
  if (![totalCents,depositCents,vat].every(Number.isFinite) || totalCents<0 || depositCents<0 || depositCents>totalCents || vat<0 || vat>100) throw Error('Controlla totale, IVA e acconto. L’acconto non può superare il totale.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw Error('Data non valida.');
  const pickup = text(input.estimated_pickup_date,10) || null;
  if (pickup && pickup<date) throw Error('Il ritiro previsto precede l’accettazione.');
  if (!STATUSES.includes(input.repair_status)) throw Error('Stato pratica non valido.');
  const signature = input.signature_data || existing?.signature_data || null;
  if (signature && (!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(signature) || signature.length>1500000)) throw Error('Firma non valida.');
  const complete=input.mode==='complete';
  if (complete && (!input.consent || !signature)) throw Error('Per l’accettazione completa servono consenso e firma del cliente.');
  const id=existing?.id ?? newId(), code=existing?.practice_code || `EGY-${date.replaceAll('-','')}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
  const net = Math.round(totalCents/(1+vat/100))/100;
  return { ...(existing || {}), id, workspace_owner_id:WORKSPACE, created_by:existing?.created_by || identity.userId,
    repaired_at:date, accepted_at:existing?.accepted_at||now, created_at:existing?.created_at||now,
    client_name:client, customer_phone:text(input.customer_phone,40)||null,customer_email:text(input.customer_email,160)||null,
    store:'EGYPHONE', device, repair_type:work, reported_issue:text(input.reported_issue,1000)||null,
    device_condition:text(input.device_condition,1000)||null,accessories:text(input.accessories,1000)||null,
    imei_serial:text(input.imei_serial,100)||null,price_ex_vat:net,vat_rate:vat,total_inc_vat:money(totalCents),vat_amount:Math.round((money(totalCents)-net)*100)/100,
    deposit_amount:money(depositCents),quote_amount:money(totalCents),quote_status:text(input.quote_status,50)||'Da diagnosticare',
    practice_code:code,receipt_token:existing?.receipt_token||code,repair_status:input.repair_status,
    estimated_pickup_date:pickup,delivered_at:input.repair_status==='Consegnato'?(existing?.delivered_at||now):null,
    warranty_months:Number(existing?.warranty_months||0),invoiced:existing?.invoiced||false,note:text(input.note)||null,
    signature_data:signature,signed_at:signature?(existing?.signed_at||now):null,
    intake_terms_accepted_at:input.consent?(existing?.intake_terms_accepted_at||now):existing?.intake_terms_accepted_at||null,
    intake_terms_version:input.consent?'BT-INTAKE-2026-10-v1':existing?.intake_terms_version||null,
    privacy_notice_version:input.consent?'BT-PRIVACY-2026-10-v1':existing?.privacy_notice_version||null,
    photo_paths:existing?.photo_paths||[], updated_at:existing?.updated_at||now };
}
function normalizeClient(input,existing,identity) {
  const display_name=text(input.display_name,120);if(!display_name)throw Error('Inserisci il nome del cliente.');
  const now=new Date().toISOString();
  return {...(existing||{}),id:existing?.id??newId(),workspace_owner_id:WORKSPACE,created_by:existing?.created_by||identity.userId,
    display_name,client_type:input.client_type==='business'?'business':'private',phone:text(input.phone,40)||null,email:text(input.email,160)||null,
    tax_code:text(input.tax_code,30).toUpperCase()||null,vat_number:text(input.vat_number,30)||null,address:text(input.address,240)||null,
    zip_code:text(input.zip_code,12)||null,city:text(input.city,100)||null,province:text(input.province,4).toUpperCase()||null,
    country:'IT',notes:text(input.notes)||null,active:input.active!==false,created_at:existing?.created_at||now,updated_at:existing?.updated_at||now};
}
const repairKeys=['id','workspace_owner_id','created_by','repaired_at','accepted_at','store','client_name','customer_phone','customer_email','device','repair_type','reported_issue','device_condition','accessories','imei_serial','price_ex_vat','vat_rate','deposit_amount','quote_amount','quote_status','practice_code','receipt_token','repair_status','estimated_pickup_date','delivered_at','warranty_months','invoiced','note','signature_data','signed_at','intake_terms_accepted_at','intake_terms_version','privacy_notice_version','photo_paths'];
function cloudPayload(entity,row,update=false){
  const keys=entity==='workshop'?['id','workspace_owner_id','created_by','data']:entity==='repairs'?repairKeys:['id','workspace_owner_id','created_by','client_type','display_name','phone','email','tax_code','vat_number','recipient_code','pec','address','zip_code','city','province','country','notes','active'];
  const payload=Object.fromEntries(keys.filter(k=>row[k]!==undefined).map(k=>[k,row[k]]));
  if(update){delete payload.id;delete payload.created_by;delete payload.workspace_owner_id;payload.updated_at=new Date().toISOString();}
  return payload;
}
class Engine {
  constructor(state,persist,remote){this.state=state;this.state.workshop??={};this.persist=persist;this.remote=remote;this.status='offline';this.message='';this.busy=false;}
  save(entity,input){
    if(!this.state.identity)throw Error('Accedi prima di salvare.');
    if(!['repairs','clients','workshop'].includes(entity))throw Error('Entità non valida.');const old=input.id?this.state[entity][input.id]:null;if(input.id&&!old&&entity!=='workshop')throw Error('Elemento non trovato.');
    const row=entity==='workshop'?{id:1,workspace_owner_id:WORKSPACE,created_by:old?.created_by||this.state.identity.userId,data:clone(input.data),updated_at:old?.updated_at||new Date().toISOString()}:entity==='repairs'?normalizeRepair(input,old,this.state.identity):normalizeClient(input,old,this.state.identity);
    const prior=this.state.queue.find(q=>q.entity===entity&&q.id===row.id);
    if(prior?.conflict)throw Error('Risolvi prima il conflitto di questa pratica.');
    const photos=input.photos||[];
    if(photos.length>6||photos.some(p=>typeof p!=='string'||p.length>7000000||!/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(p)))throw Error('Usa al massimo 6 foto JPEG/PNG, fino a 5 MB ciascuna.');
    if(prior){prior.row=clone(row);prior.error=null; if(photos.length)prior.photos=[...(prior.photos||[]),...photos].slice(0,6);}
    else this.state.queue.push({entity,id:row.id,kind:old?'update':'create',base:old?clone(old):null,row:clone(row),photos,error:null,conflict:null});
    this.state[entity][row.id]=row;this.persist(this.state);return row;
  }
  async sync(){
    if(this.busy)return;this.busy=true;this.status='syncing';this.message='';
    try{
      await this.remote.verify(this.state.identity);
      this.state.identity.verifiedAt=new Date().toISOString();
      for(const op of [...this.state.queue]){
        if(op.conflict)continue;
        try{
          if(op.photos?.length){
            const paths=await this.remote.uploadPhotos(op.id,op.photos);
            this.state.photoCache[op.id]=[...(this.state.photoCache[op.id]||[]),...op.photos];
            op.row.photo_paths=[...new Set([...(op.row.photo_paths||[]),...paths])];op.photos=[];this.persist(this.state);
          }
          const result=await this.remote.push(op);
          if(result.conflict){op.conflict=result.cloud||{deleted:true};op.error='Modificata anche online: scegli quale versione conservare.';}
          else {this.state[op.entity][op.id]=result.row;this.state.queue=this.state.queue.filter(q=>q!==op);}
          this.persist(this.state);
        }catch(e){op.error=e.message;this.persist(this.state);if(e.network)throw e;}
      }
      for(const entity of Object.keys(TABLES)){
        const rows=await this.remote.pull(entity);const next=Object.fromEntries(rows.map(r=>[r.id,r]));
        for(const op of this.state.queue.filter(q=>q.entity===entity))next[op.id]=op.row;
        this.state[entity]=next;
      }
      this.state.lastSync=new Date().toISOString();this.status=this.state.queue.some(q=>q.conflict)?'conflict':this.state.queue.length?'pending':'online';this.persist(this.state);
    }catch(e){this.status=e.auth?'locked':'offline';this.message=e.message;}
    finally{this.busy=false;}
  }
  resolve(entity,id,choice){
    const op=this.state.queue.find(q=>q.entity===entity&&q.id===id);if(!op?.conflict)throw Error('Conflitto non trovato.');
    if(choice==='cloud'){
      if(op.conflict.deleted)delete this.state[entity][id];else this.state[entity][id]=op.conflict;
      this.state.queue=this.state.queue.filter(q=>q!==op);
    }else if(choice==='local'){
      if(op.conflict.deleted)throw Error('La voce è stata eliminata online: conserva i dati in una nuova pratica.');
      op.base=clone(op.conflict);op.conflict=null;op.error=null;op.kind='update';
    }else throw Error('Scelta non valida.');this.persist(this.state);
  }
}
module.exports={WORKSPACE,TABLES,STATUSES,TERMS,Engine,emptyState,cloudPayload,normalizeRepair,normalizeClient,gross,cents};
