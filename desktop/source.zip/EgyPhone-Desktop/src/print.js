'use strict';
const QRCode=require('qrcode');
const {gross,TERMS}=require('./core');
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const euro=v=>new Intl.NumberFormat('it-IT',{style:'currency',currency:'EUR'}).format(Number(v)||0);
async function documentHtml(r,type,doc,data={}){
  if(['label','labels','clientLabel'].includes(type))return require('./intake-labels').labelsHtml(r,type==='labels'?'both':type==='clientLabel'?'client':'device',data);
  if(type==='courtesy')return require('./courtesy-print').courtesyHtml(doc);
  const code=r.practice_code||`RIP-${r.id}`,url=`https://egyphone.beparytech.it/?practice=${encodeURIComponent(code)}`;
  const qr=await QRCode.toDataURL(url,{errorCorrectionLevel:'M',margin:2,width:300});
  const total=gross(r),deposit=Number(r.deposit_amount||0),balance=Math.max(0,total-deposit);
  const safeSignature=typeof r.signature_data==='string'&&/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(r.signature_data)?r.signature_data:null;

  return `<!doctype html><meta charset="utf-8"><style>@page{size:A4;margin:16mm}body{font:11pt Arial;color:#1c273a;line-height:1.5}header{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #d6a839;padding-bottom:12px}h1{font-size:26pt;margin:0}h2{font-size:17pt}header img{width:25mm}table{border-collapse:collapse;width:100%}td{padding:8px;border-bottom:1px solid #ddd;vertical-align:top}td:first-child{width:30%;color:#657087}.total{background:#f4f6f8;padding:15px;margin-top:20px}.terms{font-size:8pt;margin-top:24px}.signature{width:65mm;height:20mm;object-fit:contain}footer{font-size:8pt;color:#657087;margin-top:12px}</style><header><div><h1>EGYPHONE</h1><div>Viale Dante Alighieri 98 · Piacenza</div><div>Tel. 3801246605 · P. IVA 01753890332</div></div><img src="${qr}"></header><h2>Ricevuta di presa in carico</h2><table>${[['Pratica',code],['Data',r.repaired_at],['Cliente',r.client_name],['Contatti',[r.customer_phone,r.customer_email].filter(Boolean).join(' · ')],['Dispositivo',r.device],['IMEI / seriale',r.imei_serial],['Difetto dichiarato',r.reported_issue],['Intervento',r.repair_type],['Condizioni / accessori',[r.device_condition,r.accessories].filter(Boolean).join(' · ')],['Ritiro previsto',r.estimated_pickup_date],['Note',r.note]].map(([k,v])=>`<tr><td>${k}</td><td>${esc(v||'—')}</td></tr>`).join('')}</table><div class="total"><b>Totale preventivato: ${euro(total)} · IVA inclusa</b><br>Acconto: ${euro(deposit)} · Saldo: ${euro(balance)}</div><p class="terms">${esc(TERMS)}</p>${r.intake_terms_accepted_at?`<p class="terms">Condizioni e informativa accettate: ${esc(new Date(r.intake_terms_accepted_at).toLocaleString('it-IT'))}</p>`:'<p class="terms">Accettazione rapida: firma e consenso da completare.</p>'}${safeSignature?`<img class="signature" src="${safeSignature}"><div>Firma cliente</div>`:''}<footer>Riepilogo di presa in carico. Non è un documento fiscale.</footer>`;
}
module.exports={documentHtml};
