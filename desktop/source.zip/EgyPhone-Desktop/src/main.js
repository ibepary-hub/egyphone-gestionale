'use strict';
const {app,BrowserWindow,ipcMain,dialog,safeStorage,Menu,shell}=require('electron');
const path=require('node:path'),fs=require('node:fs');
const {createClient}=require('@supabase/supabase-js');
const {Engine,emptyState,WORKSPACE,STATUSES,TERMS}=require('./core');
const {Vault,makePin,checkPin}=require('./vault');
const {Remote}=require('./remote');const workshop=require('./workshop');const {documentHtml}=require('./print');const analytics=require('./analytics');const catalog=require('./catalog');const services=require('./services');
const URL='https://kqdcbrpykaboabjglwxu.supabase.co',KEY='sb_publishable_h_JHhQI97d8RTKBz8oiLeQ_uCg26kxX';
let unlockStore,updater,installingUpdate=false;
let win,vault,engine,client,unlocked=false,demo=false,authStore,queue=Promise.resolve(),failures=0,blockedUntil=0;
const smoke=process.argv.includes('--smoke-test');
if(smoke)app.setPath('userData',path.join(app.getPath('temp'),'egyphone-desktop-smoke'));
if(!smoke && !app.requestSingleInstanceLock())app.quit();
function exclusive(fn){const next=queue.then(fn,fn);queue=next.catch(()=>{});return next;}
function notify(){win?.webContents.send('egyphone:changed');}
function requireUnlocked(){if(!unlocked)throw Error('Sblocca l’app per continuare.');
  if(!demo && Date.now()-new Date(engine.state.identity?.verifiedAt||0).getTime()>7*86400000){unlocked=false;throw Error('Ricollegati a Internet e accedi per rinnovare l’accesso offline.');}}
function createEngine(){const state=vault.read('data',emptyState());engine=new Engine(state,s=>vault.write('data',s),new Remote(client));}
async function timedFetch(url,options={}){const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),10000);try{return await fetch(url,{...options,signal:options.signal?AbortSignal.any([options.signal,controller.signal]):controller.signal});}finally{clearTimeout(timeout);}}
function startDemo(){demo=true;unlocked=true;const state=emptyState();state.identity={userId:'demo',email:'Modalità dimostrativa',verifiedAt:new Date().toISOString()};
  const remote={verify:async()=>{throw Error('La demo è locale e non invia dati al cloud.');}};
  engine=new Engine(state,()=>{},remote);
  for(const r of [{client_name:'Giulia Rossi',device:'iPhone 15 Pro',repair_type:'Sostituzione display',total:149,deposit_amount:30,repair_status:'In lavorazione',customer_phone:'333 000 0000'}, {client_name:'Marco Bianchi',device:'Samsung Galaxy S23',repair_type:'Sostituzione batteria',total:65,deposit_amount:0,repair_status:'Pronto'}, {client_name:'Sara Conti',device:'iPhone 13',repair_type:'Diagnosi connettore di ricarica',total:45,deposit_amount:0,repair_status:'Da diagnosticare'}])engine.save('repairs',{...r,mode:'quick',vat_rate:22});
  engine.save('clients',{display_name:'Giulia Rossi',phone:'333 000 0000',client_type:'private'});const d=workshop.initial();const fixtures=[['iPhone 13',89,30],['Galaxy A54',119,52],['iPhone 12',79,22],['Redmi Note 13',95,38],['iPhone 14 Pro',179,88],['Galaxy S23',85,28],['iPhone 14',119,45]];
  fixtures.forEach(([device,total,cost],index)=>{const date=new Date();date.setDate(date.getDate()-(6-index));date.setHours(12,0,0,0);const at=date.toISOString();const r=engine.save('repairs',{client_name:'Cliente dimostrativo '+(index+1),device,repair_type:'Riparazione',total,deposit_amount:0,repair_status:'Consegnato',mode:'quick'});engine.state.repairs[r.id].delivered_at=at;d.pieces.push({id:'DEMO-RC-'+index,itemId:'DEMO-ART',repairId:r.id,status:'used',cost,usedAt:at,supplier:'Fornitore dimostrativo'});d.documents.push({id:'DEMO-SC-'+index,kind:'pickup',repairId:r.id,at,total,deposit:0,paidNow:total,method:'Carta / POS',depositMethod:'Nessun incasso',due:0,device,work:'Riparazione',client:r.client_name,practice:r.practice_code,collector:r.client_name});});
  const unknown=engine.save('repairs',{client_name:'Cliente con costo da completare',device:'iPhone 11',repair_type:'Riparazione',total:69,deposit_amount:0,repair_status:'Consegnato',mode:'quick'});engine.state.repairs[unknown.id].delivered_at=new Date().toISOString();engine.save('workshop',{id:1,data:d});engine.state.queue=[];engine.status='demo';notify();}
async function renderDocument(id,type,mode,doc){requireUnlocked();const r=engine.state.repairs[id];if(!r)throw Error('Pratica non trovata.');
  if(mode==='print'&&require('./direct-print').isLabel(type))return require('./dymo-native').print({BrowserWindow,documentHtml,repair:r,type,data:workshop.data(engine.state),printer:engine.state.settings.printer});
  const labelContext=workshop.data(engine.state);let html=await documentHtml(r,type,doc,labelContext);if(['label','labels','clientLabel'].includes(type))html=require('./label-settings').html(html,engine.state.settings.label);const unused=0,printWin=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
  try{await printWin.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html));
    if(mode==='pdf'){
      const out=await dialog.showSaveDialog(win,{defaultPath:`EGYPHONE_${r.practice_code}.pdf`,filters:[{name:'PDF',extensions:['pdf']}]});if(out.canceled)return false;
      const pdf=await printWin.webContents.printToPDF({printBackground:true,preferCSSPageSize:true});fs.writeFileSync(out.filePath,pdf);return true;
    }
    const printing=require('./direct-print');const printers=printing.isLabel(type)?await win.webContents.getPrintersAsync():[];const options=printing.options(type,engine.state.settings,printers);
    await new Promise((resolve,reject)=>printWin.webContents.print(options,(ok,reason)=>ok?resolve():reject(Error(reason||'Invio alla stampante non riuscito.'))));return true;
  }finally{printWin.destroy();}}
const allowedActions=new Set(['state','login','unlock','demo','lock','logout','saveRepair','saveClient','sync','resolve','printLabel','printReceipt','pdf','printers','settings','backup','photos','openCloud','workshop','printDocument','documentPdf','openEpol','dashboard','catalogBrands','catalogSearch','saveIntake','printLabels','printerConfig','printerPreferences','testLabel','dymoCheck','dymoOriginal','getUnlock','updateStatus','updateCheck','updateDownload','updateInstall']);
async function handle(action,p={}){
  if(!allowedActions.has(action))throw Error('Operazione non consentita.');
  if(action==='updateStatus')return updater.snapshot();
  if(action==='updateCheck'){if(!updater.busy)void updater.check();return updater.snapshot();}
  if(action==='updateDownload'){if(!updater.busy)void updater.download().catch(e=>updater.set('error',{message:e.message}));return updater.snapshot();}
  if(action==='updateInstall')return require('./updater').installUpdate({updater,canInstall:()=>win.webContents.executeJavaScript('Boolean(window.egyphoneCanInstall && window.egyphoneCanInstall())'),persist:()=>{engine.persist(engine.state);if(!demo)vault.write('before-update-'+app.getVersion(),engine.state);},relaunch:file=>{app.relaunch({execPath:file,args:[]});installingUpdate=true;},quit:()=>app.quit()});
  if(action==='state'){
    if(!unlocked)return{locked:true,hasOffline:!!engine.state.identity,hasPin:!!engine.state.identity?.pin,email:engine.state.identity?.email||'',version:app.getVersion()};
    requireUnlocked();unlockStore.prune(engine.state.identity.userId,demo,engine.state.repairs);return{locked:false,demo,identity:{email:engine.state.identity.email},repairs:Object.values(engine.state.repairs),clients:Object.values(engine.state.clients),workshop:workshop.data(engine.state),queue:engine.state.queue.map(({entity,id,error,conflict,base,row})=>({entity,id,error,conflict,base,row})),status:engine.status,message:engine.message,lastSync:engine.state.lastSync,settings:engine.state.settings,statuses:STATUSES,terms:TERMS,version:app.getVersion()};
  }
  if(action==='demo'){startDemo();return true;}
  if(action==='login'){
    const pin=String(p.pin||'');if(!/^\d{6,12}$/.test(pin))throw Error('Imposta un PIN locale da 6 a 12 cifre.');
    if(demo){demo=false;createEngine();}
    const {data,error}=await client.auth.signInWithPassword({email:String(p.email||'').trim(),password:String(p.password||'')});if(error)throw Error(error.message);
    const identity={userId:data.user.id,email:data.user.email,verifiedAt:new Date().toISOString(),pin:makePin(pin)};
    try{await engine.remote.verify(identity);}catch(e){await client.auth.signOut({scope:'local'});throw e;}
    if(engine.state.identity&&engine.state.identity.userId!==identity.userId){await client.auth.signOut({scope:'local'});throw Error('Questo PC conserva dati di un altro utente. Esporta il backup e usa lo stesso account.');}
    engine.state.identity=identity;engine.persist(engine.state);unlocked=true;await engine.sync();notify();return true;
  }
  if(action==='unlock'){
    if(demo){demo=false;createEngine();}
    if(Date.now()<blockedUntil)throw Error('Troppi tentativi. Attendi 30 secondi.');
    if(!checkPin(String(p.pin||''),engine.state.identity?.pin)){failures++;if(failures>=5){blockedUntil=Date.now()+30000;failures=0;}throw Error('PIN non corretto.');}
    if(Date.now()-new Date(engine.state.identity.verifiedAt).getTime()>7*86400000)throw Error('Accesso offline scaduto: accedi online.');
    failures=0;unlocked=true;notify();return true;
  }
  if(action==='lock'){unlocked=false;if(demo){demo=false;createEngine();}notify();return true;}
  if(action==='openCloud'){await shell.openExternal('https://egyphone.beparytech.it/');return true;}
  requireUnlocked();
  if(action==='logout'){if(engine.state.queue.length&&!demo)throw Error('Ci sono modifiche non sincronizzate: sincronizza o usa Blocca.');if(!demo)await client.auth.signOut({scope:'local'});unlocked=false;if(demo){demo=false;createEngine();}notify();return true;}
  if(action==='dashboard')return analytics.dashboard(engine.state,p.period);
  if(action==='catalogBrands')return catalog.brands(engine.state);
  if(action==='catalogSearch')return catalog.search(engine.state,p);
  if(action==='getUnlock'){const r=engine.state.repairs[p.id];if(!r)throw Error('Pratica non trovata.');unlockStore.prune(engine.state.identity.userId,demo,engine.state.repairs);return unlockStore.get(engine.state.identity.userId,demo,r.id);}
  if(action==='saveIntake'){const credential=p.unlock===undefined?null:require('./unlock-data').normalize(p.unlock);const clean={...p};delete clean.unlock;const before=structuredClone(engine.state),persist=engine.persist;engine.persist=()=>{};let r;try{r=services.saveIntake(engine,clean);if(credential&&r.repair_status!=='Consegnato')unlockStore.save(engine.state.identity.userId,demo,r.id,credential);engine.persist=persist;persist(engine.state);}catch(e){engine.state=before;engine.persist=persist;throw e;}unlockStore.prune(engine.state.identity.userId,demo,engine.state.repairs);notify();return r;}
  if(action==='saveRepair'||action==='saveClient'){const r=engine.save(action==='saveRepair'?'repairs':'clients',p);notify();return r;}
  if(action==='workshop'){const result=workshop.run(engine,p.command,p);unlockStore.prune(engine.state.identity.userId,demo,engine.state.repairs);notify();return result;}
  if(action==='openEpol'){if(!/^\d+$/.test(String(p.id)))throw Error('ID non valido.');await shell.openExternal('https://www.e-pol.store/product-list/product-details/'+p.id);return true;}
  if(action==='printDocument'||action==='documentPdf'){const doc=workshop.data(engine.state).documents.find(d=>d.id===p.documentId);if(!doc)throw Error('Documento non trovato.');return renderDocument(doc.repairId,'courtesy',action==='documentPdf'?'pdf':'print',doc);}
  if(action==='sync'){if(demo)return true;await engine.sync();if(engine.status==='locked')unlocked=false;notify();return true;}
  if(action==='resolve'){engine.resolve(p.entity,Number(p.id),p.choice);notify();return true;}
  if(action==='printLabel')return renderDocument(p.id,'label','print');
  if(action==='printLabels'){if(!['both','client'].includes(p.kind))throw Error('Etichetta non valida.');return renderDocument(p.id,p.kind==='both'?'labels':'clientLabel','print');}
  if(action==='printReceipt')return renderDocument(p.id,'receipt','print');
  if(action==='pdf')return renderDocument(p.id,'receipt','pdf');
  if(action==='dymoCheck'||action==='dymoOriginal')return require('./dymo-native').diagnostic({BrowserWindow,printer:String(p.printer||engine.state.settings.printer||''),original:action==='dymoOriginal',print:p.print===true});
  if(action==='testLabel'){engine.state.repairs.TEST={id:'TEST',practice_code:'TEST-DYMO',client_name:'PROVA',device:'Etichetta di prova',repair_type:'Verifica orientamento e centratura',quote_amount:0,deposit_amount:0};try{return await renderDocument('TEST','label','print');}finally{delete engine.state.repairs.TEST;}}
  if(action==='printerConfig'||action==='printerPreferences')return require('./printer-actions').run(action,String(p.printer||engine.state.settings.printer||''));
  if(action==='printers')return(await win.webContents.getPrintersAsync()).map(x=>({name:x.name,displayName:x.displayName}));
  if(action==='settings'){if(p.label)engine.state.settings.label=require('./label-settings').normalize(p.label);engine.state.settings.printer=String(p.printer||'');engine.persist(engine.state);return true;}
  if(action==='backup'){
    const d=await dialog.showSaveDialog(win,{defaultPath:`EGYPHONE-backup-${new Date().toISOString().slice(0,10)}.egybackup`,filters:[{name:'Backup protetto EgyPhone',extensions:['egybackup']}]});if(d.canceled)return false;
    fs.writeFileSync(d.filePath,safeStorage.encryptString(JSON.stringify(engine.state)));return true;
  }
  if(action==='photos'){
    const id=Number(p.id),r=engine.state.repairs[id];if(!r)return[];
    const cached=engine.state.photoCache[id]||[];
    if(cached.length||demo)return cached;
    const photos=[];for(const key of (r.photo_paths||[]).slice(0,6)){
      if(typeof key!=='string'||!key.startsWith(WORKSPACE+'/'))continue;
      try{const d=await client.storage.from('repair-intake').download(key);if(d.error)continue;if(d.data.size>6000000)continue;const type=d.data.type;if(!['image/png','image/jpeg'].includes(type))continue;photos.push(`data:${type};base64,${Buffer.from(await d.data.arrayBuffer()).toString('base64')}`);}catch{}
    }if(photos.length){engine.state.photoCache[id]=photos;engine.persist(engine.state);}return photos;
  }
}
app.on('second-instance',()=>{if(win){win.restore();win.focus();}});
app.whenReady().then(async()=>{
  Menu.setApplicationMenu(null);
  // No cloud credentials or tokens are exposed to the renderer.
  vault=new Vault(path.join(app.getPath('userData'),'secure'),safeStorage);authStore=vault.read('auth',{});unlockStore=new (require('./unlock-data').UnlockStore)(vault);
  const storage={getItem:k=>authStore[k]||null,setItem:(k,v)=>{authStore[k]=v;vault.write('auth',authStore);},removeItem:k=>{delete authStore[k];vault.write('auth',authStore);}};
  client=createClient(URL,KEY,{auth:{storageKey:'egyphone-desktop-auth-v1',storage,persistSession:true,autoRefreshToken:true,detectSessionInUrl:false},global:{fetch:timedFetch}});
  createEngine();
  win=new BrowserWindow({width:1600,height:1000,minWidth:700,minHeight:620,title:'EgyPhone Desktop',backgroundColor:'#f5f6f8',icon:path.join(__dirname,'../assets/icon.png'),webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true}});
  updater=new (require('./updater').Updater)({current:app.getVersion(),cacheDir:path.join(app.getPath('userData'),'updates'),onChange:data=>win?.webContents.send('egyphone:update',data)});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  win.webContents.on('will-navigate',e=>e.preventDefault());
  win.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
  ipcMain.handle('egyphone:call',async(event,action,payload)=>{
    if(event.sender!==win.webContents||event.senderFrame!==win.webContents.mainFrame)return{ok:false,error:'Origine non autorizzata.'};
    try{return{ok:true,data:await exclusive(()=>handle(action,payload))};}catch(e){return{ok:false,error:e.message};}
  });
  win.on('close',e=>{if(engine.state.queue.length&&!demo&&!smoke&&!installingUpdate){const choice=dialog.showMessageBoxSync(win,{type:'info',buttons:['Chiudi, dati salvati sul PC','Resta nell’app'],defaultId:1,cancelId:1,message:`${engine.state.queue.length} modifiche sono ancora da sincronizzare.`,detail:'Sono protette sul PC e verranno inviate al prossimo accesso.'});if(choice===1)e.preventDefault();}});
  if(!smoke)win.maximize();await win.loadFile(path.join(__dirname,'index.html'));if(!smoke)setTimeout(()=>void updater.check(),8000).unref();
  setInterval(()=>{if(unlocked&&!demo)exclusive(async()=>{await engine.sync();if(engine.status==='locked')unlocked=false;notify();});},30000).unref();
  if(smoke){startDemo();await new Promise(resolve=>setTimeout(resolve,1800));const out=path.resolve(process.env.EGY_TEST_OUTPUT||'test-output');fs.mkdirSync(out,{recursive:true});
    await win.webContents.executeJavaScript('window.__smokeReady=true');
    fs.writeFileSync(path.join(out,'desktop-home.png'),(await win.webContents.capturePage()).toPNG());
    const result=await win.webContents.executeJavaScript(`(async()=>{document.querySelector('[data-action="new-quick"]').click();await new Promise(r=>setTimeout(r,800));return {form:!!document.querySelector('#repairForm'),title:document.querySelector('h1')?.textContent};})()`);
    fs.writeFileSync(path.join(out,'desktop-intake.png'),(await win.webContents.capturePage()).toPNG());
    const flow=await win.webContents.executeJavaScript(`(async()=>{
      const wait=async test=>{for(let i=0;i<100;i++){if(test())return;await new Promise(r=>setTimeout(r,50));}throw Error('UI timeout');};
      const set=(id,value)=>{document.getElementById(id).value=value;};
      await wait(()=>document.querySelectorAll('#serviceChoices input').length>5);document.querySelectorAll('#serviceChoices input')[0].click();document.querySelectorAll('#serviceChoices input')[1].click();set('servicePrice0','30');document.getElementById('servicePrice0').dispatchEvent(new Event('input'));set('servicePrice1','15');document.getElementById('servicePrice1').dispatchEvent(new Event('input'));
      set('client_name','Cliente test desktop');set('device','iPhone 14');if(document.getElementById('deviceModel')){const option=document.createElement('option');option.value='iPhone 14';option.textContent='iPhone 14';option.selected=true;document.getElementById('deviceModel').append(option);}set('repair_type','Display');set('total','45');set('deposit_amount','10');document.getElementById('deposit_amount').dispatchEvent(new Event('input')); 
      document.getElementById('repairForm').requestSubmit();await wait(()=>!!document.getElementById('newStatus'));
      set('newStatus','Pronto');document.querySelector('[data-action="save-status"]').click();await new Promise(r=>setTimeout(r,250));
      document.querySelector('[data-action="nav"][data-view="clients"]').click();await wait(()=>document.querySelector('h1')?.textContent.includes('persone'));
      const clientCreated=document.body.textContent.includes('Cliente test desktop');
      document.querySelector('[data-action="new-quick"]').click();await wait(()=>!!document.getElementById('repairForm'));
      // Leave the form explicitly through its Cancel button, then open the complete form.
      document.querySelector('[data-action="cancel-form"]').click();
      document.querySelector('[data-action="new-complete"]').click();await wait(()=>!!document.getElementById('signature'));
      await wait(()=>document.querySelectorAll('#serviceChoices input').length>5);const completeForm=!!document.getElementById('photoInput')&&!!document.getElementById('consent');
      return{quickSave:true,statusChange:true,clientCreated,completeForm};
    })()`);
    const saved=Object.values(engine.state.repairs).find(r=>r.client_name==='Cliente test desktop');
    if(!saved||saved.repair_status!=='Pronto'||saved.quote_amount!==45||!flow.clientCreated||!flow.completeForm)throw Error('Desktop UI smoke test failed.');
    fs.writeFileSync(path.join(out,'desktop-complete.png'),(await win.webContents.capturePage()).toPNG());
    fs.writeFileSync(path.join(out,'smoke.json'),JSON.stringify({...result,...flow,queueDurableInMemory:engine.state.queue.length>0}));
    const workshopFlow=await win.webContents.executeJavaScript(`(async()=>{
      const wait=async test=>{for(let i=0;i<120;i++){if(test())return;await new Promise(r=>setTimeout(r,50));}throw Error('Workshop UI timeout');};
      const click=s=>{const e=document.querySelector(s);if(!e)throw Error('Missing '+s);e.click();};
      const set=(id,v)=>{document.getElementById(id).value=v;};
      click('[data-action="cancel-form"]');click('[data-view="ws-stock"]');click('[data-action="ws-new-item"]');await wait(()=>document.getElementById('wsItemForm'));
      set('name','Display collaudo');set('brand','Apple');set('model','iPhone 14');set('sale','89');set('minimum','1');set('epolId','999001');document.getElementById('wsItemForm').requestSubmit();await wait(()=>document.getElementById('wsStockList'));
      click('[data-action="ws-receive-item"]');await wait(()=>document.getElementById('wsReceiveForm'));set('supplier','Fornitore test');set('document','DDT-TEST');set('quantity','2');set('cost','35');document.getElementById('wsReceiveForm').requestSubmit();await wait(()=>document.getElementById('wsStockList'));
      const individualPieces=document.querySelectorAll('[data-action="ws-link"]').length===2;
      click('[data-view="repairs"]');click('[data-action="detail"]');await wait(()=>document.getElementById('wsItemSelect'));click('[data-action="ws-associate"]');await wait(()=>document.querySelector('[data-action="ws-consume"]'));click('[data-action="ws-consume"]');await wait(()=>!document.querySelector('[data-action="ws-consume"]'));click('[data-action="ws-courtesy"]');await wait(()=>document.querySelector('[data-action="ws-print-doc"]'));
      return {individualPieces,association:true,consumption:true,courtesy:true};
    })()`);
    if(!workshopFlow.individualPieces)throw Error('Individual part UI failed');
    win.setSize(1500,1000);await new Promise(r=>setTimeout(r,300));fs.writeFileSync(path.join(out,'desktop-workshop.png'),(await win.webContents.capturePage()).toPNG());
    const sizes=[];for(const width of [1500,1100,760]){win.setSize(width,1000);await new Promise(r=>setTimeout(r,200));const result=await win.webContents.executeJavaScript('({width:innerWidth,scroll:document.documentElement.scrollWidth})');sizes.push(result);if(result.scroll>result.width+1)throw Error('Horizontal layout overflow '+JSON.stringify(result));}
    fs.writeFileSync(path.join(out,'workshop-smoke.json'),JSON.stringify({...workshopFlow,sizes}));
    win.setSize(1500,1000);
    const studioChecks=await win.webContents.executeJavaScript(`(async()=>{const wait=async test=>{for(let i=0;i<100;i++){if(test())return;await new Promise(r=>setTimeout(r,50));}throw Error('Studio UI timeout');};document.querySelector('[data-view="home"]').click();await wait(()=>document.getElementById('studioSales')?.textContent.includes('765'));const barWidths=[...document.querySelectorAll('.studioBarTrack span')].map(x=>x.getBoundingClientRect().width);if(!barWidths.some(x=>x>10))throw Error('Chart bars invisible');const select=document.getElementById('studioPeriod');select.value='day';select.dispatchEvent(new Event('change'));await wait(()=>document.getElementById('studioMargin')?.textContent.includes('74,00'));document.querySelector('[data-view="ws-catalog"]').click();await wait(()=>document.querySelectorAll('#catalogBrand option').length>3900);const input=document.getElementById('catalogQuery');input.value='SM-A526B';input.dispatchEvent(new Event('input'));await wait(()=>document.getElementById('catalogResults')?.textContent.includes('SM-A526B'));return{chartVisible:true,periodFilter:true,catalogTechnicalCode:true};})()`);
    const studioSizes=[];for(const width of [1500,1100,760]){win.setSize(width,1000);await new Promise(r=>setTimeout(r,200));await win.webContents.executeJavaScript(`document.querySelector('[data-view="home"]').click()`);await new Promise(r=>setTimeout(r,300));const result=await win.webContents.executeJavaScript('({width:innerWidth,scroll:document.documentElement.scrollWidth})');studioSizes.push(result);if(result.scroll>result.width+1)throw Error('Studio overflow '+JSON.stringify(result));if(width===1500)fs.writeFileSync(path.join(out,'studio-oro.png'),(await win.webContents.capturePage()).toPNG());}
    fs.writeFileSync(path.join(out,'studio-smoke.json'),JSON.stringify({...studioChecks,sizes:studioSizes}));
    const html=await documentHtml(saved,'labels',null,workshop.data(engine.state));fs.writeFileSync(path.join(out,'label.html'),html);
    const pw=new BrowserWindow({show:false,webPreferences:{sandbox:true}});await pw.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html));fs.writeFileSync(path.join(out,'label.pdf'),await pw.webContents.printToPDF({preferCSSPageSize:true,printBackground:true}));const geometry=await pw.webContents.executeJavaScript(`({pages:document.querySelectorAll('.label').length,overflow:[...document.querySelectorAll('.label')].some(x=>x.scrollHeight>x.clientHeight+1),codeVisible:[...document.querySelectorAll('.code')].every(x=>x.scrollHeight<=x.clientHeight+1)})`);if(geometry.pages!==2||geometry.overflow||!geometry.codeVisible)throw Error('Label geometry failure '+JSON.stringify(geometry));fs.writeFileSync(path.join(out,'multi-service-smoke.json'),JSON.stringify({services:workshop.data(engine.state).servicesByRepair[saved.id].lines.length,labels:geometry}));pw.destroy();app.exit(0);
  }
}).catch(e=>{if(smoke)console.error(e.stack||e.message);else dialog.showErrorBox('EgyPhone Desktop',e.message);app.exit(1);});
app.on('window-all-closed',()=>app.quit());
