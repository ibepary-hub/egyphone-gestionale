'use strict';
const {gross,cents}=require('./core');
const localDate=value=>{const d=value instanceof Date?value:new Date(value);if(!Number.isFinite(d.getTime()))return null;return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
function dashboard(state,period='month',now=new Date()){
 const end=localDate(now);if(!end)throw Error('Data non valida.');const startDate=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 if(period==='week')startDate.setDate(startDate.getDate()-((startDate.getDay()+6)%7));else if(period==='month')startDate.setDate(startDate.getDate()-29);else if(period!=='day')throw Error('Periodo non valido.');
 const start=localDate(startDate),w=state.workshop?.[1]?.data||{},pieces=w.pieces||[],documents=w.documents||[],rows=[];
 for(const r of Object.values(state.repairs||{})){
  if(r.repair_status!=='Consegnato')continue;
  const docs=documents.filter(d=>d.kind==='pickup'&&d.repairId===r.id),doc=docs.sort((a,b)=>String(a.at).localeCompare(String(b.at)))[0];
  const date=localDate(doc?.at||r.delivered_at);if(!date||date<start||date>end)continue;
  const used=pieces.filter(p=>p.repairId===r.id&&p.status==='used'),explicitZero=w.costReviewed?.[r.id]===true;
  const valid=used.every(p=>p.cost!==null&&p.cost!==undefined&&Number.isFinite(Number(p.cost))&&Number(p.cost)>=0);
  const known=valid&&(used.length>0||explicitZero),sale=cents(doc?.total??gross(r)),cost=known?used.reduce((n,p)=>n+cents(p.cost),0):null;
  if(!Number.isSafeInteger(sale)||sale<0)continue;
  rows.push({id:r.id,code:r.practice_code||String(r.id),date,device:r.device,client:r.client_name,sale,cost,margin:known?sale-cost:null,known});
 }
 rows.sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);
 const known=rows.filter(r=>r.known),missing=rows.filter(r=>!r.known),sales=known.reduce((n,r)=>n+r.sale,0),costs=known.reduce((n,r)=>n+r.cost,0),days=new Map();
 for(const r of known){const d=days.get(r.date)||{date:r.date,sale:0,cost:0,margin:0,count:0};d.sale+=r.sale;d.cost+=r.cost;d.margin+=r.margin;d.count++;days.set(r.date,d);}
 return{period,start,end,rows,sales,costs,margin:sales-costs,percentage:sales?100*(sales-costs)/sales:null,count:known.length,missingCount:missing.length,missingSales:missing.reduce((n,r)=>n+r.sale,0),allSales:rows.reduce((n,r)=>n+r.sale,0),days:[...days.values()].sort((a,b)=>a.date.localeCompare(b.date))};
}
module.exports={dashboard,localDate};
