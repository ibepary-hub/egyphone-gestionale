'use strict';
const reference=require('../assets/device-catalog.json');
const referenceKeys=new Set(reference.map(r=>r[0].toLowerCase()+'\0'+r[1].toLowerCase()));
const labels=['Archivio storico · 10/09/2021','Google Play · 02/11/2026','Ampliamento nomi della proposta','Modello personalizzato'];
function entries(state){const custom=state.workshop?.[1]?.data?.catalog||{};const rows=[];for(const [brand,models] of Object.entries(custom))for(const model of models){if(!referenceKeys.has(brand.toLowerCase()+'\0'+model.toLowerCase()))rows.push([brand,model,'',3]);}return rows.length?reference.concat(rows):reference;}
function brands(state){const counts=new Map();for(const r of entries(state))counts.set(r[0],(counts.get(r[0])||0)+1);return[...counts].map(([name,count])=>({name,count})).sort((a,b)=>a.name.localeCompare(b.name));}
function search(state,p={}){const term=String(p.query||'').trim().toLowerCase().slice(0,120),brand=String(p.brand||''),scope=p.scope||'all',limit=Math.max(1,Math.min(100,Number(p.limit)||40)),offset=Math.max(0,Number(p.offset)||0);const list=entries(state).filter(r=>(!brand||r[0]===brand)&&(scope==='all'||scope==='google'&&r[3]===1||scope==='history'&&r[3]!==1)&&(!term||(r[0]+' '+r[1]+' '+r[2]).toLowerCase().includes(term)));return{total:list.length,offset,rows:list.slice(offset,offset+limit).map(r=>({brand:r[0],model:r[1],code:r[2],source:labels[r[3]]}))};}
module.exports={brands,search};
