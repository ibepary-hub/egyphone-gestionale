'use strict';
function isLabel(type){return ['label','labels','clientLabel'].includes(type);}
function options(type,settings,printers=[]){const common={printBackground:true,margins:{marginType:'none'},copies:1,duplexMode:'simplex'};if(!isLabel(type))return {...common,silent:false};const deviceName=String(settings.printer||'').trim();if(!deviceName)throw Error('Scegli e salva la stampante DYMO in Impostazioni prima di stampare.');if(!printers.some(p=>p.name===deviceName))throw Error('La stampante DYMO salvata non è disponibile. Controlla il collegamento e la stampante scelta in Impostazioni.');return {...common,...require('./label-settings').options(settings.label),deviceName,silent:true};}
module.exports={options,isLabel};
