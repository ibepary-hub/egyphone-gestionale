'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
function normalize(p){const type=String(p?.type||'not-provided'),authorized=p?.authorized===true;let value=String(p?.value||'');if(!['none','not-provided','pin','password','pattern'].includes(type))throw Error('Tipo di sblocco non valido.');if(['pin','password','pattern'].includes(type)&&!authorized)throw Error('Registra l’autorizzazione del cliente per conservare lo sblocco.');if(type==='pin'&&!/^\d{4,16}$/.test(value))throw Error('Il PIN deve contenere da 4 a 16 cifre.');if(type==='password'&&(!value||value.length>128))throw Error('Inserisci una password di massimo 128 caratteri.');if(type==='pattern'&&(!/^[1-9]{4,9}$/.test(value)||new Set(value).size!==value.length))throw Error('Seleziona da 4 a 9 punti diversi.');if(['none','not-provided'].includes(type))value='';return{type,value,authorized,updatedAt:new Date().toISOString()};}
class UnlockStore{
 constructor(vault){this.vault=vault;this.demo={};}
 name(user){return'unlocks-'+crypto.createHash('sha256').update(String(user)).digest('hex').slice(0,24);}
 read(user,demo){return demo?this.demo:this.vault.read(this.name(user),{});}
 write(user,demo,data){if(demo){this.demo=data;return;}const n=this.name(user);this.vault.write(n,data,{backup:false});}
 get(user,demo,id){return this.read(user,demo)[id]||{type:'not-provided',value:'',authorized:false};}
 save(user,demo,id,data){const rows=this.read(user,demo);rows[id]=normalize(data);this.write(user,demo,rows);}
 prune(user,demo,repairs){const rows=this.read(user,demo);let changed=false;for(const r of Object.values(repairs))if(r.repair_status==='Consegnato'&&Object.hasOwn(rows,r.id)){delete rows[r.id];changed=true;}if(changed)this.write(user,demo,rows);}
}
module.exports={normalize,UnlockStore};
