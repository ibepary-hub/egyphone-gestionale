'use strict';
const {WORKSPACE,TABLES,cloudPayload}=require('./core');
function fail(error){const e=Error(error?.message||'Connessione cloud non disponibile.');e.network=/fetch|network|timeout|abort|ECONN|ENOTFOUND/i.test(e.message);e.auth=/JWT|token.*expired|permission denied|invalid.*refresh/i.test(e.message);throw e;}
class Remote {
  constructor(client){this.sb=client;}
  async verify(identity){
    const {data,error}=await this.sb.auth.getUser();if(error)fail(error);
    if(!data?.user||data.user.id!==identity?.userId){const e=Error('Accedi di nuovo per sincronizzare.');e.auth=true;throw e;}
    const p=await this.sb.from('beparytech_profiles').select('active,role,workspace_owner_id').eq('user_id',data.user.id).maybeSingle();if(p.error)fail(p.error);
    if(!p.data?.active||p.data.role!=='admin'||p.data.workspace_owner_id!==WORKSPACE){const e=Error('Account non autorizzato per EgyPhone Desktop.');e.auth=true;throw e;}
    const c=await this.sb.from('beparytech_companies').select('status,expires_at,modules').eq('workspace_owner_id',WORKSPACE).maybeSingle();if(c.error)fail(c.error);
    const expiry=c.data?.expires_at?new Date(c.data.expires_at.length===10?c.data.expires_at+'T23:59:59':c.data.expires_at):null;
    if(!c.data||!['active','trial'].includes(c.data.status)||expiry&&expiry<new Date()||!c.data.modules?.includes('repairs')){const e=Error('Licenza EgyPhone non attiva per le riparazioni.');e.auth=true;throw e;}
    return data.user;
  }
  async pull(entity){let all=[];for(let i=0;;i+=500){const r=await this.sb.from(TABLES[entity]).select('*').eq('workspace_owner_id',WORKSPACE).order('id').range(i,i+499);if(r.error)fail(r.error);all.push(...r.data);if(r.data.length<500)break;}return all;}
  async push(op){
    const table=TABLES[op.entity],fetch=await this.sb.from(table).select('*').eq('id',op.id).eq('workspace_owner_id',WORKSPACE).maybeSingle();if(fetch.error)fail(fetch.error);
    const cloud=fetch.data;
    if(op.kind==='create'){
      if(cloud){
        // Retry after a lost response: accept only the exact original payload.
        const expected=cloudPayload(op.entity,op.row);const matches=Object.entries(expected).every(([k,v])=>JSON.stringify(cloud[k])===JSON.stringify(v)||(typeof v==='number'&&Number(cloud[k])===v));
        return matches?{row:cloud}:{conflict:true,cloud};
      }
      const r=await this.sb.from(table).insert(cloudPayload(op.entity,op.row)).select('*').single();if(r.error)fail(r.error);return{row:r.data};
    }
    if(!cloud||cloud.updated_at!==op.base?.updated_at)return{conflict:true,cloud:cloud||{deleted:true}};
    const r=await this.sb.from(table).update(cloudPayload(op.entity,op.row,true)).eq('id',op.id).eq('workspace_owner_id',WORKSPACE).eq('updated_at',op.base.updated_at).select('*').maybeSingle();
    if(r.error)fail(r.error);return r.data?{row:r.data}:{conflict:true,cloud:(await this.sb.from(table).select('*').eq('id',op.id).eq('workspace_owner_id',WORKSPACE).maybeSingle()).data||{deleted:true}};
  }
  async uploadPhotos(id,photos){const paths=[];for(let i=0;i<photos.length;i++){
    const photo=photos[i],mime=photo.slice(5,photo.indexOf(';')),bytes=Buffer.from(photo.split(',')[1],'base64');
    const hash=require('node:crypto').createHash('sha256').update(bytes).digest('hex').slice(0,20);
    const p=`${WORKSPACE}/desktop/${id}/${hash}.${mime==='image/png'?'png':'jpg'}`;
    const r=await this.sb.storage.from('repair-intake').upload(p,bytes,{contentType:mime,upsert:false});
    if(r.error&&!/already exists|duplicate/i.test(r.error.message))fail(r.error);paths.push(p);
  }return paths;}
}
module.exports={Remote};
