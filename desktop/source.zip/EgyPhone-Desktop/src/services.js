'use strict';
const W=require('./workshop');
const DEFAULTS=['Sostituzione display','Sostituzione batteria','Vetro posteriore','Connettore di ricarica','Fotocamera anteriore','Fotocamera posteriore','Altoparlante','Microfono','Diagnosi','Riparazione scheda madre'];
function saveIntake(engine,p){
 const before=structuredClone(engine.state),persist=engine.persist;engine.persist=()=>{};
 try{
  if(!Array.isArray(p.serviceLines)||!p.serviceLines.length||p.serviceLines.length>15)throw Error('Seleziona da 1 a 15 interventi.');
  const lines=p.serviceLines.map(x=>{const name=String(x.name||'').trim(),price=Number(x.price),itemId=String(x.itemId||'');if(!name||name.length>100||!Number.isFinite(price)||price<0||price>100000)throw Error('Controlla nome e prezzo degli interventi.');if(itemId&&!W.data(engine.state).items.some(i=>i.id===itemId))throw Error('Ricambio non trovato.');return{name,price:Math.round(price*100)/100,itemId};});
  if(new Set(lines.map(x=>x.name.toLowerCase())).size!==lines.length)throw Error('Intervento duplicato.');
  const partIds=lines.map(x=>x.itemId).filter(Boolean);if(new Set(partIds).size!==partIds.length)throw Error('Lo stesso articolo è selezionato per più interventi. Associa un ricambio distinto per voce.');
  const work=lines.map(x=>x.name).join(' + ');if(work.length>240)throw Error('La descrizione totale degli interventi supera 240 caratteri. Abbrevia i nomi.');
  const method=String(p.depositMethod||'Nessun incasso');if(!W.METHODS.includes(method)||Number(p.deposit_amount)>0&&method==='Nessun incasso')throw Error('Indica la modalità di pagamento dell’acconto.');
  const old=engine.state.repairs[p.id],d0=W.data(engine.state);const doc=d0.documents.find(x=>x.repairId===old?.id&&x.kind==='courtesy');if(doc&&(doc.deposit!==Number(p.deposit_amount)||doc.total!==Number(p.total)||doc.depositMethod!==method))throw Error('Esiste già uno scontrino di acconto: importi e modalità devono coincidere.');
  const r=engine.save('repairs',{...p,repair_type:work});
  const wanted=new Map();for(const line of lines)if(line.itemId)wanted.set(line.itemId,(wanted.get(line.itemId)||0)+1);
  for(const [itemId,quantity] of wanted){const d=W.data(engine.state),linked=d.pieces.filter(x=>x.repairId===r.id&&x.itemId===itemId&&['reserved','used'].includes(x.status)).length+d.requests.filter(x=>x.repairId===r.id&&x.itemId===itemId&&!['received','cancelled'].includes(x.status)).length;for(let n=linked;n<quantity;n++)W.run(engine,'associate',{repairId:r.id,itemId});}
  const d=structuredClone(W.data(engine.state));d.servicesByRepair??={};d.servicesByRepair[r.id]={lines,depositMethod:method};d.customServices??=[];for(const x of lines)if(!DEFAULTS.includes(x.name)&&!d.customServices.includes(x.name))d.customServices.push(x.name);engine.save('workshop',{id:1,data:d});
  engine.persist=persist;persist(engine.state);return engine.state.repairs[r.id];
 }catch(e){engine.state=before;engine.persist=persist;throw e;}
}
module.exports={DEFAULTS,saveIntake};
