'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
class Vault {
  constructor(dir,safeStorage){this.dir=dir;this.safe=safeStorage;fs.mkdirSync(dir,{recursive:true,mode:0o700});}
  read(name,fallback){const file=path.join(this.dir,name+'.vault');if(!fs.existsSync(file))return fallback;
    try{return JSON.parse(this.safe.decryptString(fs.readFileSync(file)));}catch{throw Error('Archivio locale non leggibile. Non è stato sovrascritto: usa lo stesso account Windows o ripristina un backup.');}}
  write(name,data,{backup=true}={}){if(!this.safe.isEncryptionAvailable())throw Error('La protezione Windows dei dati non è disponibile.');
    const file=path.join(this.dir,name+'.vault'),tmp=file+'.tmp',buf=this.safe.encryptString(JSON.stringify(data));
    const fd=fs.openSync(tmp,'w',0o600);try{fs.writeFileSync(fd,buf);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
    if(backup&&fs.existsSync(file))fs.copyFileSync(file,file+'.bak');if(!backup)fs.rmSync(file+'.bak',{force:true});fs.renameSync(tmp,file);}
}
function makePin(pin){if(!/^\d{6,12}$/.test(pin))throw Error('Scegli un PIN da 6 a 12 cifre.');const salt=crypto.randomBytes(16).toString('hex');return{salt,hash:crypto.scryptSync(pin,salt,32).toString('hex')};}
function checkPin(pin,record){if(!record?.salt||!record?.hash)return false;const a=crypto.scryptSync(String(pin),record.salt,32),b=Buffer.from(record.hash,'hex');return a.length===b.length&&crypto.timingSafeEqual(a,b);}
module.exports={Vault,makePin,checkPin};
