'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('egyphone',{
  onUpdate:callback=>{const h=(_event,data)=>callback(data);ipcRenderer.on('egyphone:update',h);return()=>ipcRenderer.removeListener('egyphone:update',h);},
  call:(action,payload)=>ipcRenderer.invoke('egyphone:call',action,payload),
  onChange:callback=>{const h=()=>callback();ipcRenderer.on('egyphone:changed',h);return()=>ipcRenderer.removeListener('egyphone:changed',h);}
});
