const {contextBridge}=require('electron');contextBridge.exposeInMainWorld('egyphone',{call:async action=>({ok:true,data:action==='state'?{locked:true}:[]}),onChange:()=>{}});
