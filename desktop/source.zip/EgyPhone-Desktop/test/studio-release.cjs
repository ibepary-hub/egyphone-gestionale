'use strict';
const fs=require('fs'),path=require('path'),Module=require('module');const file=path.resolve(__dirname,'../src/main.js');let source=fs.readFileSync(file,'utf8');
const extra=`
win.setSize(1680,1050);await new Promise(r=>setTimeout(r,150));
const releaseChecks=await win.webContents.executeJavaScript(\`(async()=>{
 const pause=ms=>new Promise(r=>setTimeout(r,ms)),wait=async f=>{for(let i=0;i<100;i++){if(f())return;await pause(50);}throw Error('Release UI timeout');};
 const secret='Egy-test-only-private-729451';
 const r=await api('saveIntake',{client_name:'Collaudo riservato',device:'Samsung Galaxy S24',mode:'quick',total:149,deposit_amount:0,repair_status:'In lavorazione',serviceLines:[{name:'Display',price:149,itemId:''}],depositMethod:'Nessun incasso',unlock:{type:'password',value:secret,authorized:true}});
 if((await api('getUnlock',{id:r.id})).value!==secret)throw Error('Unlock not saved');
 if(JSON.stringify(await api('state')).includes(secret))throw Error('Credential leaked through state/queue');
 selected=r.id;view='intake';formMode='quick';await refresh(true);await wait(()=>document.getElementById('deviceUnlockValue')?.value===secret);if(document.getElementById('deviceUnlockValue').type!=='password')throw Error('Password not masked');
 document.querySelector('[data-unlock-type="pattern"]').click();for(const n of [1,3,6,9])document.querySelector('[data-dot="'+n+'"]').dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
 if(document.getElementById('repairForm').readUnlock().value!=='12369')throw Error('Android midpoint ordering incorrect');
 document.querySelector('.unlockCard').scrollIntoView();await pause(100);return {id:r.id,masked:true,patternMidpoint:true,stateExcludesUnlock:true};})()\`);
fs.writeFileSync(path.join(out,'studio-unlock.png'),(await win.webContents.capturePage()).toPNG());
await handle('workshop',{command:'pickup',repairId:releaseChecks.id,depositMethod:'Nessun incasso',method:'Contanti',confirm:true});if((await handle('getUnlock',{id:releaseChecks.id})).value)throw Error('Pickup retained credentials');
const printerChecks=await win.webContents.executeJavaScript(\`(async()=>{
 view='settings';await refresh(true);await new Promise(r=>setTimeout(r,200));const sel=document.getElementById('printer');sel.innerHTML='<option value="DYMO">DYMO LabelWriter 450</option>';let fail=true;const real=api;api=async(a,p)=>{if(a==='settings')return true;if(a==='dymoCheck'){if(fail)throw Error('RenderLabel. Error: 400');return{preview:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aPFUAAAAASUVORK5CYII=',verified:true};}return real(a,p);};
 await document.getElementById('dymoVerify').onclick();await new Promise(r=>setTimeout(r,80));if(!document.getElementById('dymoPrint').disabled||!document.getElementById('dymoAppStatus').textContent.includes('400'))throw Error('Failed verification enabled print');
 fail=false;await document.getElementById('dymoVerify').onclick();await new Promise(r=>setTimeout(r,80));if(document.getElementById('dymoPrint').disabled)throw Error('Verified print unavailable');
 sel.dispatchEvent(new Event('change'));if(!document.getElementById('dymoPrint').disabled)throw Error('Printer change retained verification');api=real;document.getElementById('dymoExtras').scrollIntoView({block:'start'});await new Promise(r=>setTimeout(r,250));return{errorBlocksPrint:true,verifiedEnablesPrint:true,changeResetsVerification:true};})()\`);
fs.writeFileSync(path.join(out,'studio-printer.png'),(await win.webContents.capturePage()).toPNG());fs.writeFileSync(path.join(out,'release-checks.json'),JSON.stringify({...releaseChecks,pickupDeletesUnlock:true,...printerChecks}));
`;
source=source.replace('pw.destroy();app.exit(0);','pw.destroy();'+extra+'app.exit(0);');const m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));m._compile(source,file);
