Aggiornamenti EgyPhone all’avvio

• Avviso automatico quando è disponibile una versione più recente.
• Download con verifica di integrità e pulsante “Chiudi e installa”.
• Blocco installazione quando ci sono schede aperte da salvare.
• Copia protetta dei dati prima dell’installazione.
• Comando “Controlla ora” nelle Impostazioni.

Mantiene la correzione DYMO e i pulsanti Impostazioni / Stampante sempre accessibili della versione 1.5.1.
