# EgyPhone Desktop 1.6.0 — Studio Oro

## Aggiornamenti automatici (dalla 1.6.0)

Installa la 1.6.0 una prima volta. Le versioni 1.5.x non contengono il controllo aggiornamenti. Dalla 1.6.0, circa 8 secondi dopo l’apertura l’app cerca una nuova versione stabile nel repository dedicato `ibepary-hub/egyphone-gestionale`. Il controllo non blocca l’accesso né il lavoro offline. Nelle Impostazioni trovi Aggiornamenti → Controlla ora.

Se è disponibile una versione più recente, compare il popup Studio Oro con le novità e Scarica aggiornamento / Più tardi. Il file è scaricato soltanto su richiesta. A download completato, Chiudi e installa ricontrolla l’integrità del file, salva i dati locali, crea una copia protetta prima dell’aggiornamento e apre l’installatore dopo la chiusura dell’app. Il programma di installazione mantiene il percorso dei dati e l’utente completa l’installazione come negli aggiornamenti precedenti.

L’installazione viene bloccata se ci sono schede da salvare o finestre operative aperte. Installa più tardi lascia continuare il lavoro. La scelta di rimandare non annulla un download già avviato. I pacchetti provengono solo dal repository configurato, devono essere per EgyPhone Windows x64 e superare i controlli su versione, dimensione e SHA256. Non vengono installate versioni uguali o precedenti. Nessun token GitHub è incluso nell’app.

La pubblicazione di una nuova versione avviene caricando i sorgenti in `desktop/source.zip`: il workflow Windows costruisce il pacchetto, esegue i test e rende visibile il rilascio soltanto quando tutti i file sono caricati. Vedi `desktop/README.md` nel repository per la procedura. Una versione già pubblicata non viene sovrascritta.

Questa versione mantiene le correzioni di stampa 1.5.1. L’installazione su un PC Windows e il riavvio effettivo dopo l’aggiornamento non sono eseguibili in questo ambiente; la verifica fisica DYMO mantiene i limiti precedenti.

## Installazione
Chiudi EgyPhone Desktop e installa nella stessa cartella della versione precedente. Windows 10/11 a 64 bit; installatore non firmato digitalmente. L’aggiornamento mantiene il percorso dei dati locali. Prima di aggiornare puoi esportare un backup protetto da Impostazioni.

## Grafica Studio Oro
Menu laterale antracite, pulsanti oro, sfondo avorio, testi grandi e disposizione adattiva. Il nuovo stile si applica alle sezioni del gestionale, con una barra EgyPhone / Studio Oro.

## PIN, password e sequenza
In accettazione rapida e completa trovi “Sblocco dispositivo”: Nessun blocco, PIN, Password, Sequenza o Non fornito. Il PIN conserva gli zeri iniziali; per la sequenza puoi trascinare il mouse tra i punti o selezionarli da tastiera. I punti intermedi seguono la regola Android.

L’autorizzazione del cliente è inizialmente non selezionata e deve essere registrata prima di conservare un codice. PIN e password sono mascherati; Mostra li rende visibili per 15 secondi. Nella scheda della riparazione “Mostra sblocco” mostra il dato per 15 secondi. Non inserire codici nelle note.

I dati di sblocco sono cifrati in un archivio separato, protetto dall’account Windows, associato alla singola pratica. Sono accessibili a chi ha sbloccato l’app su quel PC: non è introdotto un nuovo sistema di ruoli per tecnico. Sono esclusi da stato generale, coda cloud, etichette, QR, ricevute ed esportazione backup ordinaria. **Restano soltanto su questo PC: non sono sincronizzati con il cloud né disponibili su altri computer.** Vengono rimossi dall’archivio operativo al ritiro, anche quando uno stato Consegnato arriva dalla sincronizzazione. Il programma non mantiene copie precedenti dell’archivio dei codici. Copie esterne del disco non sono controllate dall’app.

## Pannello DYMO
Servono DYMO Connect e il suo servizio Web avviato. Il modello rimane Durable 1933084 (57 × 32 mm nominali), usando il file fornito.

1. Seleziona e salva la DYMO.
2. “Prova modello originale” verifica il file originale e, se accettato, invia una sola etichetta di prova con il contenuto originale.
3. “Verifica anteprima” verifica l’etichetta EgyPhone con QR e prezzo. Non stampa. Se riesce, mostra l’immagine restituita dal servizio DYMO e abilita “Stampa 1 etichetta”.
4. Controlla il risultato fisico della prova prima di stampare le due etichette della pratica.

Un cambio di stampante richiede una nuova verifica. Gli errori sono visibili e copiabili con Copia diagnostica. Non viene dichiarata riuscita una stampa fisica sulla base dell’accettazione del comando.

Correzione 1.5.1: il componente nativo DYMO legge ImageObject in sequenza: Name, Brushes, Rotation, OutlineThickness, IsOutlined, BorderStyle, Margin, Data, ScaleMode, HorizontalAlignment, VerticalAlignment, ObjectLayout. La versione precedente metteva HorizontalAlignment e VerticalAlignment prima di Data: il lettore interpretava “Middle” come ScaleMode, valore non ammesso. La sequenza è stata corretta e verificata contro WriteProperties/ReadProperties del componente ufficiale DYMO.LabelAPI, distribuito da DYMO.Connect.SDK 1.4.3.37. Il controllo del framework JavaScript da solo non rilevava questa incompatibilità.

Impostazioni e Stampante DYMO sono ora disponibili nella barra superiore fissa; l’elenco laterale scorre separatamente dal contenuto. Test di visibilità alle dimensioni 1920 × 1080, 1366 × 768, 1024 × 768 e 760 × 900.

La geometria del modello originale rimane invariata. Nessun invio quando la verifica fallisce e nessuna ristampa automatica con esito incerto. La prova fisica e il servizio DYMO del PC del cliente non sono stati eseguiti qui.

## Funzioni esistenti
Rubrica, interventi multipli, magazzino manuale, entrata merci con ID individuali, pezzi Da ordinare, acconto e saldo, prezzi IVA inclusa, dashboard costi e margine sui ricambi e catalogo dispositivi. Nessun catalogo ricambi E-POL precaricato. Il margine esclude altre spese e non equivale all’utile netto. Il selettore italiano/arabo conserva la copertura parziale precedente; documenti e testi legali restano italiani.

## Collaudo
50 test automatici superati. Flussi già collaudati nella versione 1.5.0: accettazione, clienti, magazzino, documenti, dashboard e adattamento a tre larghezze; salvataggio e mascheramento dello sblocco, ordinamento della sequenza, esclusione dalla coda e cancellazione al ritiro. Test del pannello DYMO già eseguiti nella 1.5.0 con risposte simulate: l’errore blocca la prova, la verifica la abilita e cambiare stampante la disabilita. Test del framework ufficiale per geometria, immagine, chiusure XML, ordine di verifica delle due etichette e mancato invio dopo errore.

**Non eseguiti qui:** installazione su Windows, servizio DYMO reale, stampa fisica e collaudo cloud con due PC. Le verifiche simulate non dimostrano che la stampante abbia prodotto un’etichetta corretta.
